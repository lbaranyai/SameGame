SameGame - logical strategy game
=====================================================
Developer: lbaranyai@github


1. Install

Download ZIP package and extract to any folder. The
software is ready to play. Available at:

https://github.com/lbaranyai/SameGame

Content is:
- samegame.exe			binary
- borlndmm.dll			dynamic library
- cc32240mt.dll			dynamic library

2. Requirements

Software is running on Windows(TM) computers. Binary
is compiled to 32 bit systems, it is compatible from
Windows XP but more recent version is recommended.

Samegame is tiny program, using only 2 MB memory and
4 MB disk space.

3. Liability

Software was tested to work as expected but provided
AS IS. Developer cannot guarantee profit or special
advantage, neither liable for damages or loss of profit
caused by modification or misuse. Anyone can use free
and also check its source code, compile his/her own
version.

4. License

This software was created for fun, not for profit.
Anyone can use free according to the 

Creative Commons BY-NC 3.0
http://creativecommons.org/licenses/by-nc/3.0/
